mkdir $1 #Create a direction with name given as argument
cp Homework1/mcode.sty ./$1/
cp Homework1/Header.tex ./$1/
mkdir $1/figures
